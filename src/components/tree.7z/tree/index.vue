/**
* Created by 王冬 on 2017/9/5.
* QQ: 20004604
* weChat: qq20004604
*/

<template>
  <div>
    <item :data='testData' :level='0' :marginLeft="marginLeft"></item>
  </div>
</template>
<style scoped>


</style>
<script>
  import item from './treeItem.vue'

  export default {
    data () {
      return {
        testData: {
          'name': '前端工程师',
          'children': [
            {
              'name': '页面',
              'children': [
                {
                  'name': 'HTML'
                },
                {
                  'name': 'CSS',
                  'children': [
                    {
                      'name': 'CSS reset'
                    },
                    {
                      'name': '选择器'
                    },
                    {
                      'name': '盒模型',
                      'children': [
                        {
                          'name': '传统盒模型'
                        },
                        {
                          'name': '弹性盒子布局Flex'
                        }
                      ]
                    }
                  ]
                },
                {
                  'name': '脚本',
                  'children': [
                    {
                      'name': 'EcmaScript'
                    },
                    {
                      'name': 'BOM',
                      'children': [
                        {
                          'name': 'history'
                        },
                        {
                          'name': 'window'
                        },
                        {
                          'name': 'location'
                        }
                      ]
                    },
                    {
                      'name': 'DOM',
                      'children': [
                        {
                          'name': 'DOM类型'
                        },
                        {
                          'name': 'DOMapi'
                        },
                        {
                          'name': '事件流'
                        },
                        {
                          'name': '表单',
                          'children': [
                            {
                              'name': '富文本编辑器'
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            {
              'name': '工程化',
              'children': [
                {
                  'name': 'MV*框架',
                  'children': [
                    {
                      'name': 'Angular'
                    },
                    {
                      'name': 'VueJs'
                    },
                    {
                      'name': 'ReactJs'
                    }
                  ]
                },
                {
                  'name': '自动化、模块化工具',
                  'children': [
                    {
                      'name': 'Gulp'
                    },
                    {
                      'name': 'Webpack'
                    }
                  ]
                },
                {
                  'name': '编辑器',
                  'children': [
                    {
                      'name': 'VScode'
                    },
                    {
                      'name': 'WebStorm'
                    },
                    {
                      'name': 'Sublime'
                    }
                  ]
                }
              ]
            },
            {
              'name': '移动端',
              'children': [
                {
                  'name': '响应式设计'
                },
                {
                  'name': 'WebView'
                },
                {
                  'name': 'Web端',
                  'children': [
                    {
                      'name': '响应式编程'
                    },
                    {
                      'name': '尺寸rem,em'
                    }
                  ]
                },
                {
                  'name': 'IOS'
                },
                {
                  'name': 'Android'
                }
              ]
            },
            {
              'name': '网络通信',
              'children': [
                {
                  'name': '服务器及服务器中间件'
                },
                {
                  'name': 'http协议'
                },
                {
                  'name': 'ajax请求',
                  'children': [
                    {
                      'name': '同源策略，跨域请求'
                    }
                  ]
                }
              ]
            },
            {
              'name': '版本管理工具',
              'children': [
                {
                  'name': 'Git'
                },
                {
                  'name': 'SVN'
                }
              ]
            },
            {
              'name': '浏览器',
              'children': [
                {
                  'name': '浏览器种类',
                  'children': [
                    {
                      'name': 'Chrome'
                    },
                    {
                      'name': 'firefox'
                    },
                    {
                      'name': 'Internet'
                    }
                  ]
                },
                {
                  'name': '浏览器渲染流程'
                }
              ]
            },
            {
              'name': 'SEO搜索引擎优化'
            }
          ]
        },
        marginLeft: 30
      }
    },
    methods: {},
    components: {
      item
    }
  }
</script>
