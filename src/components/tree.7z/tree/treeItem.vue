/**
* Created by 王冬 on 2017/9/5.
* QQ: 20004604
* weChat: qq20004604
*/

<template>
  <div :style="itemStyle">
    <!--<div>level: {{level}}</div>-->
    <div>
      <span>{{level}}：{{data.name}}</span>
      <input type="text" v-model="val">
      <button @click="addItem">+</button>
    </div>
    <template v-for="(val, key) in data.children">
      <tree-item :data="val" :level="Number(level + 1)"></tree-item>
    </template>
  </div>
</template>
<style scoped>


</style>
<script>
  export default {
    name: 'tree-item',
    props: {
      data: {
        type: Object
      },
      level: {
        type: Number
      },
      marginLeft: {
        type: Number,
        default: 20
      }
    },
    data () {
      return {
        itemStyle: {
          'margin-left': this.marginLeft + 'px'
        },
        val: ''
      }
    },
    methods: {
      addItem () {
        if (this.val.length === 0) {
          return
        }
        if (!this.data.children) {
          this.$set(this.data, 'children', [])
        }
        this.data.children.push({
          name: this.val
        })
      }
    }
  }
</script>
